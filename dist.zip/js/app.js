'use strict';

var appStyles = {
  width: '800px',
  marginLeft: 'auto',
  marginRight: 'auto'
};
var App = React.createClass({
  displayName: 'App',

  getInitialState: function getInitialState() {
    return {
      viewingPage: window.location.search === '?settings' ? 'settings' : 'home'
    };
  },
  componentWillMount: function componentWillMount() {
    lbry.checkNewVersionAvailable(function (isAvailable) {
      if (isAvailable) {
        alert("The version of LBRY you're using is not up to date.\n\n" + "You'll now be taken to lbry.io, where you can download the latest version.");
        window.location = "http://www.lbry.io/" + (navigator.userAgent.indexOf('Mac OS X') != -1 ? 'osx' : 'linux');
      }
    });
  },
  componentDidMount: function componentDidMount() {
    lbry.getStartNotice(function (notice) {
      if (notice) {
        alert(notice);
      }
    });
  },
  render: function render() {
    if (this.state.viewingPage == 'home') {
      var content = React.createElement(HomePage, null);
    } else if (this.state.viewingPage == 'settings') {
      var content = React.createElement(SettingsPage, null);
    }
    return React.createElement(
      'div',
      { style: appStyles },
      content
    );
  }
});