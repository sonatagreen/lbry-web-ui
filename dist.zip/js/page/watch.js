'use strict';

var videoStyle = {
  width: '100%',
  height: '100%',
  backgroundColor: '#000'
};

var WatchPage = React.createClass({
  displayName: 'WatchPage',

  propTypes: {
    name: React.PropTypes.string
  },
  getInitialState: function getInitialState() {
    return {
      downloadStarted: false,
      readyToPlay: false,
      loadStatusMessage: "Requesting stream"
    };
  },
  componentDidMount: function componentDidMount() {
    lbry.getStream(this.props.name);
    this.updateLoadStatus();
  },
  updateLoadStatus: function updateLoadStatus() {
    var _this = this;

    lbry.getFileStatus(this.props.name, function (status) {
      if (!status || status.code != 'running' || status.written_bytes == 0) {
        // Download hasn't started yet, so update status message (if available) then try again
        if (status) {
          _this.setState({
            loadStatusMessage: status.message
          });
        }
        setTimeout(function () {
          _this.updateLoadStatus();
        }, 250);
      } else {
        _this.setState({
          readyToPlay: true
        });
        flowplayer('player', 'js/flowplayer/flowplayer-3.2.18.swf');
      }
    });
  },
  render: function render() {
    return React.createElement(
      'main',
      null,
      React.createElement(
        'div',
        { className: this.state.readyToPlay ? 'hidden' : '' },
        React.createElement(
          'h3',
          null,
          'Loading lbry://',
          this.props.name
        ),
        this.state.loadStatusMessage,
        '...'
      ),
      React.createElement('a', { id: 'player', href: "/view?name=" + this.props.name, style: videoStyle })
    );
  }
});