'use strict';

var settingsRadioOptionStyles = {
  display: 'block',
  marginLeft: '13px'
},
    settingsCheckBoxOptionStyles = {
  display: 'block',
  marginLeft: '13px'
},
    settingsNumberFieldStyles = {
  width: '40px'
},
    downloadDirectoryLabelStyles = {
  fontSize: '.9em',
  marginLeft: '13px'
},
    downloadDirectoryFieldStyles = {
  width: '300px'
};

var SettingsPage = React.createClass({
  displayName: 'SettingsPage',

  storeSetting: function storeSetting(setting, val) {
    var settings = Object.assign({}, this.state.settings);
    settings[setting] = val;
    this.setState({
      'settings': settings
    });
    lbry.setSettings(settings);
  },
  onRunOnStartChange: function onRunOnStartChange(event) {
    this.storeSetting('run_on_startup', event.target.checked);
  },
  onShareDataChange: function onShareDataChange(event) {
    this.storeSetting('upload_log', event.target.checked);
  },
  onDownloadDirChange: function onDownloadDirChange(event) {
    this.storeSetting('download_directory', event.target.value);
  },
  onMaxUploadPrefChange: function onMaxUploadPrefChange(isLimited) {
    if (!isLimited) {
      this.storeSetting('max_upload', 0.0);
    }
    this.setState({
      isMaxUpload: isLimited
    });
  },
  onMaxUploadFieldChange: function onMaxUploadFieldChange(event) {
    this.storeSetting('max_upload', Number(event.target.value));
  },
  onMaxDownloadPrefChange: function onMaxDownloadPrefChange(isLimited) {
    if (!isLimited) {
      this.storeSetting('max_download', 0.0);
    }
    this.setState({
      isMaxDownload: isLimited
    });
  },
  onMaxDownloadFieldChange: function onMaxDownloadFieldChange(event) {
    this.storeSetting('max_download', Number(event.target.value));
  },
  getInitialState: function getInitialState() {
    return {
      settings: null
    };
  },
  componentWillMount: function componentWillMount() {
    lbry.getSettings(function (settings) {
      this.setState({
        settings: settings,
        isMaxUpload: settings.max_upload != 0,
        isMaxDownload: settings.max_download != 0
      });
    }.bind(this));
  },
  render: function render() {
    if (!this.state.settings) {
      // If the settings aren't loaded yet, don't render anything.
      return null;
    }

    return React.createElement(
      'main',
      null,
      React.createElement(
        'h1',
        null,
        'Settings'
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Run on startup'
        ),
        React.createElement(
          'label',
          { style: settingsCheckBoxOptionStyles },
          React.createElement('input', { type: 'checkbox', onChange: this.onRunOnStartChange, defaultChecked: this.state.settings.run_on_startup }),
          ' Run LBRY automatically when I start my computer'
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Download directory'
        ),
        React.createElement(
          'div',
          { className: 'help' },
          'Where would you like the files you download from LBRY to be saved?'
        ),
        React.createElement('input', { style: downloadDirectoryFieldStyles, type: 'text', name: 'download_directory', defaultValue: this.state.settings.download_directory, onChange: this.onDownloadDirChange })
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Max Upload'
        ),
        React.createElement(
          'label',
          { style: settingsRadioOptionStyles },
          React.createElement('input', { type: 'radio', name: 'max_upload_pref', onChange: this.onMaxUploadPrefChange.bind(this, false), defaultChecked: !this.state.isMaxUpload }),
          ' Unlimited'
        ),
        React.createElement(
          'label',
          { style: settingsRadioOptionStyles },
          React.createElement('input', { type: 'radio', name: 'max_upload_pref', onChange: this.onMaxUploadPrefChange.bind(this, true), defaultChecked: this.state.isMaxUpload }),
          ' ',
          this.state.isMaxUpload ? 'Up to' : 'Choose limit...',
          React.createElement(
            'span',
            { className: this.state.isMaxUpload ? '' : 'hidden' },
            ' ',
            React.createElement('input', { type: 'number', min: '0', step: '.5', defaultValue: this.state.settings.max_upload, style: settingsNumberFieldStyles, onChange: this.onMaxUploadFieldChange }),
            ' MB/s'
          )
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Max Download'
        ),
        React.createElement(
          'label',
          { style: settingsRadioOptionStyles },
          React.createElement('input', { type: 'radio', name: 'max_download_pref', onChange: this.onMaxDownloadPrefChange.bind(this, false), defaultChecked: !this.state.isMaxDownload }),
          ' Unlimited'
        ),
        React.createElement(
          'label',
          { style: settingsRadioOptionStyles },
          React.createElement('input', { type: 'radio', name: 'max_download_pref', onChange: this.onMaxDownloadPrefChange.bind(this, true), defaultChecked: this.state.isMaxDownload }),
          ' ',
          this.state.isMaxDownload ? 'Up to' : 'Choose limit...',
          React.createElement(
            'span',
            { className: this.state.isMaxDownload ? '' : 'hidden' },
            ' ',
            React.createElement('input', { type: 'number', min: '0', step: '.5', defaultValue: this.state.settings.max_download, style: settingsNumberFieldStyles, onChange: this.onMaxDownloadFieldChange }),
            ' MB/s'
          )
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Share diagnostic data'
        ),
        React.createElement(
          'label',
          { style: settingsCheckBoxOptionStyles },
          React.createElement('input', { type: 'checkbox', onChange: this.onShareDataChange, defaultChecked: this.state.settings.upload_log }),
          ' Help make LBRY better by contributing diagnostic data about my usage'
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(Link, { href: '/', label: '<< Return' })
      )
    );
  }
});